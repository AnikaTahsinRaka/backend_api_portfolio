const Portfolio = require('../models/portfolioModel');
const User = require('../models/userModel');

// Create a new portfolio
const createPortfolio = async (req, res) => {
  const { title, description, img, codelink, livelink } = req.body;
  try {
    const portfolio = new Portfolio({
      title,
      description,
      img,
      codelink,
      livelink,
      user: req.userId
    });
    await portfolio.save();
    res.status(201).json({ message: 'Portfolio created successfully', portfolio });
  } catch (err) {
    res.status(500).json({ error: 'Error creating portfolio' });
  }
};

// Get all portfolios
const getPortfolios = async (req, res) => {
  try {
    const portfolios = await Portfolio.find({ user: req.userId });
    res.json(portfolios);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching portfolios' });
  }
};

// Update a portfolio
const updatePortfolio = async (req, res) => {
  const { id } = req.params;
  const { title, description, img, codelink, livelink } = req.body;
  try {
    const portfolio = await Portfolio.findById(id);
    if (!portfolio) return res.status(404).json({ error: 'Portfolio not found' });
    if (portfolio.user.toString() !== req.userId)
      return res.status(403).json({ error: 'Not authorized' });

    portfolio.title = title || portfolio.title;
    portfolio.description = description || portfolio.description;
    portfolio.img = img || portfolio.img;
    portfolio.codelink = codelink || portfolio.codelink;
    portfolio.livelink = livelink || portfolio.livelink;

    await portfolio.save();
    res.json({ message: 'Portfolio updated successfully', portfolio });
  } catch (err) {
    res.status(500).json({ error: 'Error updating portfolio' });
  }
};

// Delete a portfolio
const deletePortfolio = async (req, res) => {
  const { id } = req.params;
  try {
    const portfolio = await Portfolio.findById(id);
    if (!portfolio) return res.status(404).json({ error: 'Portfolio not found' });
    if (portfolio.user.toString() !== req.userId)
      return res.status(403).json({ error: 'Not authorized' });

    await portfolio.remove();
    res.json({ message: 'Portfolio deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Error deleting portfolio' });
  }
};

module.exports = { createPortfolio, getPortfolios, updatePortfolio, deletePortfolio };
